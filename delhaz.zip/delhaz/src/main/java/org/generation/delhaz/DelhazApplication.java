package org.generation.delhaz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DelhazApplication {

	public static void main(String[] args) {
		SpringApplication.run(DelhazApplication.class, args);
	}

}
